#!/usr/bin/perl

use strict;

($#ARGV+2) ==6 || die
"Usage: getChanges.pl file.txt isHeader colX lag=1 opt=0/1/2
       Compute for column x, the lagged changes(pct ret, log ret, just diff)
       lag: 1=1-day lag ret, 2=2-day lag ret, etc
       opt: 0=pct change, (x2-x1)/x1
            1=log ret, log(x2/x1)
            2=just difference, x2-x1
       Output: ... chg\n";



my $filename=$ARGV[0];
open(INFILE, "$filename") || die "Couldn't open $filename: $!\n";
my $isHeader=$ARGV[1];
my $colX=$ARGV[2];
my $lag=$ARGV[3];
my $op=$ARGV[4];


my @line;
my @xs;
my @lines;
my $header="NA";
my $count=0;
while(<INFILE>)
{
    #chomp the new line at the end
    chomp($_);
    my $str=$_;
    $count++;

    if($isHeader==1 && $count==1)
    {
      $header=$str;
      next;
    }

    @line =split;
    my $x=$line[$colX-1];
    push(@xs,$x);
    push(@lines,$str);
}
close(INFILE);


if($isHeader)
{
   print "$header chg\n";
}
my $start=$lag;

foreach my $i ($lag..$#xs)
{
    my $x1=$xs[$i-$lag];
    my $x2=$xs[$i];

    my $str=$lines[$i];

    my $chg="NA";
    if($op==0)
    {
       $chg=($x2-$x1)/$x1;
    }
    elsif($op==1)
    {
       $chg=log($x2/$x1);
    }
    elsif($op==2)
    {
       $chg=$x2-$x1;
    }
    else
    {
       print "Error: operation no defined\n";
       exit(0);
    }

    printf "$str %.7f\n",$chg;

}


