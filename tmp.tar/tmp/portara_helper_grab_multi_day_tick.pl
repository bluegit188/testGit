#!/usr/bin/perl

use File::Basename;
use strict;


my $DEBUG=0;

($#ARGV+2)==4 || die
"Usage: portara_helper_grab_multi_day_tick.pl SYM startDate endDate
        Extract normalized cum. volume for a date range
        Output: DATE HHMM cumVol.norm\n";

my $sym=$ARGV[0]; # portara text file
my $date1 =$ARGV[1];
my $date2 =$ARGV[2];


    my $cmd="
 cat /mnt/wbox1/portara/Futures/Continuous\\ Contracts/Intraday\\ Database/1\\ Minute\\ 24Hr/$sym.001 | sed s/,/\\ /g|fgrep -v DATE|gawk '{if(\$1>=$date1 && \$1<=$date2){print \$1,\$2,\$7}}' > /tmp/tmpVols.txt
# 35 sec
# only keep non weekend dates
check_duplicate.pl /tmp/tmpVols.txt 1|mygetcols.pl 1|myDayOfWeek.pl 0 1|myRmOutliersSimple.pl 0 2 1 5 1 >/tmp/tmpDates.txt
";
system("$cmd");


# open file an dput column specified into a hash
my $filename="/tmp/tmpDates.txt";
open(INFILE, "$filename") || die "Couldn't open $filename: $!\n";

my @line; 
while(<INFILE>)
{
    #chomp the new line at the end
    chomp($_);
    @line =split;

    my $date=$line[0];
    my $cmd1="
   ## loop each date
   cat  /tmp/tmpVols.txt |egrep -E -e\"^$date \"|myPortaraAddMissingMinutes.pl 1 2 3|mygetcols.pl 1 2 5
";
   # print "$cmd1\n";
    system("$cmd1");


}
close(INFILE);









__END__


--cmd:
time cat /mnt/wbox1/portara/Futures/Continuous\ Contracts/Intraday\ Database/1\ Minute\ 24Hr/EU.001 | sed s/,/\ /g|fgrep -v DATE|gawk '{if($1>=20150115 && $1<=20150115){print $1,$2,$7}}' > /tmp/tmpVol.txt
# 35 sec
cat /tmp/tmpVol.txt|myPortaraAddMissingMinutes.pl 1 2 3|mygetcols.pl 1 2 6 >/tmp/tmpVolNorm.txt 
timesXmgr.pl /tmp/tmpVolNorm.txt 2 0|mygetcols.pl 1 4 2 3  >/tmp/tmpForplot.txt
xmgrByTime /tmp/tmpForplot.txt&


