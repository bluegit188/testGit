#!/usr/bin/perl

use File::Basename;
use strict;


my $DEBUG=0;

( ($#ARGV+2)==4 || ($#ARGV+2)==5 ) || die
"Usage: portara_plot_tick_avgCumVol_24Hr_easy.pl SYM dateStart dateEnd [opt: plotOff=0/1]
       Plot averaged cummulate volume(normalized to 1) for given symbol and a given period; alos create a pdf file
       Opt: plotOff=0(plot by default), 1=turn off plot\n";

my $sym=$ARGV[0]; # portara text file
my $date1 =$ARGV[1];
my $date2 =$ARGV[2];


my $plotOff=0;
if(($#ARGV+2)==5 )
{
  $plotOff=$ARGV[3];

}

    my $cmd="
portara_plot_tick_avgCumVol_24Hr.pl $sym $date1 $date2 $plotOff
cp  /tmp/tmpForplot2.txt.$sym .
";
   # print "$cmd\n";
    system("$cmd");

# for xmgr batch file
my $temp="read block \"/tmp/tmpForplot2.txt.$sym\"
block xy \"1:2\"
s0 line color 1
s0 linewidth 2
title \"$sym cumVol normalized (avg. over a year)\"
xaxis label \"time\"
yaxis label \"cumVol\"
PRINT TO \"$sym.eps\"
DEVICE \"EPS\" OP \"level2\"
PRINT";

my $bfile="xmgr.batch";
open(OUT1,">$bfile") ||die "Cannot open $bfile: $!\n";

print OUT1 "$temp\n";


    my $cmd2="
xmgrByTime -batch $bfile -nosafe -hardcopy
ps2pdf $sym.eps
";
  system("$cmd2");



## add the chg of cumVol tex file as well
    my $cmd3="
getChanges.pl tmpForplot2.txt.$sym 0 2 1 2|mygetcols.pl 1 6 2:5 > tmpForplot2.txt.$sym.chg
#xmgrByTimetmpForplot2.txt.$sym.chg &
";
  system("$cmd3");


__END__


--cmd:




-- print to eps automatically:


--cmd
time portara_plot_tick_avgCumVol_24Hr.pl BP 20140101 20150131
xmgrByTime -batch tmp.bfile -nosafe -hardcopy
ps2pdf test.eps



portara_plot_tick_avgCumVol_24Hr_easy.pl BP 20140101 20140131
