#!/usr/bin/perl

use strict;


($#ARGV+2) ==4 || die 
"Usage:timesXmgr.pl file colTime formatOpt=0/1/2
       Convert time column to xmgr format: 00000000-01-01-09:30:15.000
       formatOpt: 0=HHMM, 1=HHMMSS\n";



my $filename=$ARGV[0];
open(INFILE, "$filename") || die "Couldn't open $filename: $!\n";


my $colTime=$ARGV[1];

my $formatOpt=$ARGV[2];



my @line;
my $day=1;
while(<INFILE>)
{
    #chomp the new line at the end
    chomp($_);
    @line =split;

    my $str=$_;

    my $time=$line[$colTime-1];

    if($formatOpt==0) #HHMM
    {
      $time=$time."00";
    }
    elsif($formatOpt==1) #HHMMSS
    {
      $time=$time;
    }
    else
    {
      $time=$time;
    }

    ## get hh/mm/ss
    my $year=2000;
    my $month=1;
    #my $day=1;

    my $hour=get_hour_from_HHMMSS($time);
    my $min=get_min_from_HHMMSS($time);
    my $sec=get_sec_from_HHMMSS($time);

    #if pasisng midnight, increase day by 1
    if($hour==0 && $min==0 & $sec==0) # this needs fix if using actual tick data
    {
      $day+=1;
    }

    #print "hh/mm/ss= $hour, $min, $sec\n";
    #print $time, "Y=",get_year($time)," M=",get_month($time)," D=",get_day_of_month($time),"\n";

    #xmgr time str:  1999-12-31-23:59:59.5
    my $timeStr=sprintf( "%04d-%02d-%02d-%02d:%02d:%02d",$year,$month,$day,$hour,$min,$sec);

    print "$timeStr $str\n";

}
close(INFILE);


sub get_month
#20150213 
# return 2
{
   my ($date) = @_;
   #my $YYYY=int($date/10000);
   my $MMDD=$date%10000;
   my $MM=int($MMDD/100);
   return $MM;
}

sub get_year
#20150213 
# return 2
{
   my ($date) = @_;
   my $YYYY=int($date/10000);
   #my $MMDD=$date%10000;
   #my $MM=int($MMDD/100);
   return $YYYY;
}

sub get_day_of_month
#20150213 
# return 2
{
   my ($date) = @_;
   #my $YYYY=int($date/10000);
   my $MMDD=$date%10000;
   #my $MM=int($MMDD/100);
   my $DD=$MMDD%100;
   return $DD;
}



sub get_hour_from_HHMMSS
# 143005 ( 2:30PM, 5 sec)
# return 14
{
   my ($hhmmss) = @_;
   my $hh=int($hhmmss/10000);
   #my $mmss=$hhmmss%10000;
   #my $mm=int($mmss/100);
   #my $ss=$mmss%100;
   return $hh;
}



sub get_min_from_HHMMSS
# 143005 ( 2:30PM, 5 sec)
# return 30
{
   my ($hhmmss) = @_;
   #my $hh=int($hhmmss/10000);
   my $mmss=$hhmmss%10000;
   my $mm=int($mmss/100);
   #my $ss=$mmss%100;
   return $mm;
}


sub get_sec_from_HHMMSS
# 143005 ( 2:30PM, 5 sec)
# return 5
{
   my ($hhmmss) = @_;
   #my $hh=int($hhmmss/10000);
   my $mmss=$hhmmss%10000;
   #my $mm=int($mmss/100);
   my $ss=$mmss%100;
   return $ss;
}



__END__

for 48-hour span,

0.5 / 12 hour


each hour is 0.04166667
1/24
[1] 0.04166667

2/24=0.125
[1] 0.125 => one mark/3 hours


starting on hour 0, 3,6,9,12 seems to make displaying  better


one year: 365.25 vs 265.2425
