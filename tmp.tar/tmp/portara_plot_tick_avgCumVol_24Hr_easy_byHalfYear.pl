#!/usr/bin/perl

use File::Basename;
use strict;


my $DEBUG=0;

( ($#ARGV+2)==4 || ($#ARGV+2)==5 ) || die
"Usage: portara_plot_tick_avgCumVol_24Hr_easy_byHalfYear.pl SYM startYear(2002) endYear(2014) [opt: plotOff=0/1]
       Plot avg. cumVol for each half year from 2002 to 2014
       Create a big pdf file at end
       Opt: plotOff=0(plot by default), 1=turn off plot\n";

my $sym=$ARGV[0]; # portara text file
my $year1 =$ARGV[1];
my $year2 =$ARGV[2];


my $plotOff=0;
if(($#ARGV+2)==5 )
{
  $plotOff=$ARGV[3];

}


my @files;

foreach my $year ($year1..$year2)
{

    my $date1=$year."0101";
    my $date2=$year."0630";
    my $cmd1="
portara_plot_tick_avgCumVol_24Hr.pl $sym $date1 $date2 $plotOff
cp  /tmp/tmpForplot2.txt.$sym .
getChanges.pl tmpForplot2.txt.$sym 0 2 1 2|mygetcols.pl 1 6 2:5 > tmpForplot2.txt.$sym.chg.$year.H1
";
   # print "$cmd1\n";
    system("$cmd1");

    xmgr_print_to_eps("tmpForplot2.txt.$sym.chg.$year.H1","$sym $year H1");

    $date1=$year."0701";
    $date2=$year."1231";
    my $cmd2="
portara_plot_tick_avgCumVol_24Hr.pl $sym $date1 $date2 $plotOff
cp  /tmp/tmpForplot2.txt.$sym .
getChanges.pl tmpForplot2.txt.$sym 0 2 1 2|mygetcols.pl 1 6 2:5 > tmpForplot2.txt.$sym.chg.$year.H2
";
   # print "$cmd2\n";
    system("$cmd2");

    xmgr_print_to_eps("tmpForplot2.txt.$sym.chg.$year.H2","$sym $year H2");


    push(@files,"tmpForplot2.txt.$sym.chg.$year.H1.eps");
    push(@files,"tmpForplot2.txt.$sym.chg.$year.H2.eps");

}


# put all eps into one file:
my $allFiles=join(" ",@files);
    my $cmd3="
mpage -1 $allFiles >aa
ps2pdf aa all_halfYears.$sym.pdf
";
#print "$cmd3\n";
  system("$cmd3");

sub xmgr_print_to_eps
#print cum plot to eps file
{
    my ($file, $title) = @_;

# for xmgr batch file
my $temp="read block \"$file\"
block xy \"1:2\"
s0 line color 1
s0 linewidth 2
title \"$title\"
xaxis label \"time\"
yaxis label \"cumVol\"
PRINT TO \"$file.eps\"
DEVICE \"EPS\" OP \"level2\"
PRINT";

my $bfile="xmgr.batch";
open(OUT1,">$bfile") ||die "Cannot open $bfile: $!\n";

print OUT1 "$temp\n";

    my $cmd2="
xmgrByTime -batch $bfile -nosafe -hardcopy -autoscale y
#ps2pdf $sym.eps
";
  system("$cmd2");

    return 0;
}

__END__


--cmd:




-- print to eps automatically:


--cmd
time portara_plot_tick_avgCumVol_24Hr.pl BP 20140101 20150131
xmgrByTime -batch tmp.bfile -nosafe -hardcopy
ps2pdf test.eps



portara_plot_tick_avgCumVol_24Hr_easy.pl BP 20140101 20140131
