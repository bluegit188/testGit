#!/usr/bin/perl

use File::Basename;
use strict;


my $DEBUG=0;

( ($#ARGV+2)==4 || ($#ARGV+2)==5 ) || die
"Usage: portara_plot_tick_avgCumVol_24Hr.pl SYM dateStart dateEnd [opt: plotOff=0/1]
       Plot averaged cummulate volume(normalized to 1) for given symbol and a given period
       Opt: plotOff=0(plot by default), 1=turn off plot\n";

my $sym=$ARGV[0]; # portara text file
my $date1 =$ARGV[1];
my $date2 =$ARGV[2];

my $plotOff=0;
if( ($#ARGV+2)==5 )
{
  $plotOff=$ARGV[3];
}

    my $cmd="
portara_helper_grab_multi_day_tick.pl $sym $date1 $date2  > /tmp/tmpCumVols.txt

  getMeanStdByDate.pl /tmp/tmpCumVols.txt 0 2 3 |mygetcols.pl 1 4 5 6 >/tmp/tmpAvgVolNorm.txt

timesXmgr.pl /tmp/tmpAvgVolNorm.txt 1 0 |mygetcols.pl 1 3 2 4 5  >/tmp/tmpForplot2.txt.$sym
";
    #print "$cmd\n";
    system("$cmd");

if(!$plotOff)
{
    my $cmd2="
xmgrByTime /tmp/tmpForplot2.txt.$sym&
";
    #print "$cmd2\n";
    system("$cmd2");

  }
__END__


--cmd:
time cat /mnt/wbox1/portara/Futures/Continuous\ Contracts/Intraday\ Database/1\ Minute\ 24Hr/EU.001 | sed s/,/\ /g|fgrep -v DATE|gawk '{if($1>=20150115 && $1<=20150115){print $1,$2,$7}}' > /tmp/tmpVol.txt
# 35 sec
cat /tmp/tmpVol.txt|myPortaraAddMissingMinutes.pl 1 2 3|mygetcols.pl 1 2 6 >/tmp/tmpVolNorm.txt 
timesXmgr.pl /tmp/tmpVolNorm.txt 2 0|mygetcols.pl 1 4 2 3  >/tmp/tmpForplot.txt
xmgrByTime /tmp/tmpForplot.txt&


