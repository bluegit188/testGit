#!/usr/bin/perl

use strict;

($#ARGV+2)==4 || die 
"Usage: myPortaraAddMissingMinutes.pl colDate colHHMM colVol
       Given input of format: DATE HHMM tickVol
       Add in miutes without data and then cummulate volume
       Output: DATE HHMM minIndex cumVol cumVolInPct\n";


my @allMins=(0)x1440; # 24*60
#print join(",",@allMins),"\n";


my $colDate=$ARGV[0];
my $colHHMM=$ARGV[1];
my $colVol=$ARGV[2];


my $sum=0;
my $count=0;
my @line; 
my $date;
while(<STDIN>)
{
    #chomp the new line at the end
    chomp($_);
    @line =split;
    my $HHMM = $line[$colHHMM-1];
    my $vol = $line[$colVol-1];
    $date = $line[$colDate-1];


    my $minIndex=index_in_min_HHMMSS($HHMM."00");

    $allMins[$minIndex]=$vol;
    $sum+=$vol;
    #print "$_ $minIndex\n";

}

#print "sum=$sum\n";


# out all HHMM(missing minutes added), and normalize it
my $cumVol=0;
foreach my $mIdx (0..$#allMins)
{
  my $HHMM= get_HHMM_from_min_index($mIdx);
  my $vol=$allMins[$mIdx];
  $cumVol+=$vol;
  my $norm=0;
  if($sum !=0)
  {
    $norm=$cumVol/$sum*100;
  }
  printf "$date $HHMM $mIdx $cumVol %.4f\n",$norm;
}




sub get_hour_from_HHMMSS
# 143005 ( 2:30PM, 5 sec)
# return 14
{
   my ($hhmmss) = @_;
   my $hh=int($hhmmss/10000);
   #my $mmss=$hhmmss%10000;
   #my $mm=int($mmss/100);
   #my $ss=$mmss%100;
   return $hh;
}



sub get_min_from_HHMMSS
# 143005 ( 2:30PM, 5 sec)
# return 30
{
   my ($hhmmss) = @_;
   #my $hh=int($hhmmss/10000);
   my $mmss=$hhmmss%10000;
   my $mm=int($mmss/100);
   #my $ss=$mmss%100;
   return $mm;
}


sub get_sec_from_HHMMSS
# 143005 ( 2:30PM, 5 sec)
# return 5
{
   my ($hhmmss) = @_;
   #my $hh=int($hhmmss/10000);
   my $mmss=$hhmmss%10000;
   #my $mm=int($mmss/100);
   my $ss=$mmss%100;
   return $ss;
}

sub index_in_min_HHMMSS
#input: 14:30:05
# output: 14*60+30, can range from 0 to 1439
{
  my ($hhmmss) = @_;
  return get_hour_from_HHMMSS($hhmmss)*60+get_min_from_HHMMSS($hhmmss);
}

sub get_HHMM_from_min_index
#input: minute index
# output: time in HHMM format
{
  my ($minIndex) = @_;

  my $hour=int($minIndex/60);
  my $min=$minIndex-60*$hour;
  my $timeStr=sprintf( "%02d%02d",$hour,$min);
  return $timeStr;
}
