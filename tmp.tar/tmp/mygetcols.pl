#!/usr/bin/perl

use strict;

($#ARGV+2) >=2 || die 
"Usage: mygetcols.pl n1 n2 n3 5:7 ...\n";





my @n;
foreach my $i (0..$#ARGV)
{
  my $str=$ARGV[$i];
  my @tokens=split(':',$str);
  if($#tokens==0)
  {
    push(@n,$str);         # the n's
  }
  else
  {
     foreach my $k ( ($tokens[0])..($tokens[1]))
     {
       push(@n,$k);
     }
  }
}

#print join(" ", @n), "\n";



my @line; 
while(<STDIN>)
{
    #chomp the new line at the end
    chomp($_);
    @line =split;

    my $str;

    foreach my $j (0..$#n)
    {
        my $k=$n[$j];
        #print "k=$k\n";
        my $thisStr=$line[$k-1];
        $str=$str."$thisStr ";
    }
    #chomp $str;  # remove the last space
    # remove last space
    $str=~s/\s+$//;
    print "$str\n";

}


