#' MS Function
#'
#' This function allows to get the maximize sharpe ratio
#' @param model model
#' @param data data
#' @keywords SharpeRatio
#' @export
#' @examples
#' MS(ooF1D~bt1FcstDM,dat0)
#'
#' # create X quartiles
#' dat0$X <- (dat0$fvChg.1)
#' dat0$XQtr <- cut(dat0$X, c(-Inf, quantile(dat0$X, c(25,50,75,100)/100, na.rm =T) ))
#' MS(ooF1D~bt1FcstDM:I(XQtr), data = dat0)

MS <- function(model, data) {
    # Check inputs
    if (missing(data))
        stop("Need to specify the data table.")
    if (!any("DATE" == colnames(data))) {
        stop("data need DATE column!!")
    }

    data <- data.table::data.table(data)

    mf <- model.frame(formula=model, data=data)
    y <- model.response(mf)
    x <- model.matrix(attr(mf, "terms"), data=mf)

    len <- length(unique(data$DATE))
    qtrLen <- dim(x)[2]
    SiMat <- matrix(, len, qtrLen)
    data$y <- y
    for (i in c(1:qtrLen)) {
        data$tempMS_x <- x[,i]
        tempTable <- data %>%
            dplyr::group_by(DATE) %>%
            dplyr::summarise(temp = sum(y* tempMS_x))
        SiMat[,i] <- tempTable$temp
    }

    M <- colMeans(SiMat)
    Stemp <- SiMat - matrix(rep(M, len), len, qtrLen, byrow = T)
    S <- 1/(len-1)* t(Stemp) %*% Stemp

    L <- chol(S)
    A <- t(solve(L)) %*% t(t(M)) %*% t(M) %*% solve(L)

    A <- eigen(A)$vectors %*% diag(eigen(A)$values) %*% t(eigen(A)$vectors)
    lmCoefs <- Re(solve(t(eigen(A)$vectors) %*% L, c(1, rep(0, qtrLen-1))))

    yhat <- x %*% lmCoefs
    # rescale
    tempLM <- lm(y~yhat)
    lmCoefs <- tempLM$coefficients['yhat']* lmCoefs
    yhat <- x %*% lmCoefs
    if (sum(y*yhat) < 0) {
        yhat <- -yhat
        lmCoefs <- -lmCoefs
    }
    MSCoefs = data.table( attr(x, 'dimnames')[[2]],round(lmCoefs,digits=7))
    names(MSCoefs) = c("indicator", "coef")

    res <- list()
    res$coefList <- MSCoefs
    res$fcst <- yhat
    return(res)
}
