#' printSharpeRatio Function
#'
#' This function allows to get the Sharpe Ratio
#' y = yvar vector
#' fcst =xvar vector
#' @param data data
#' @param y observations
#' @param fcst forecasts
#' @param pos position of contracts
#' @param tcost cost
#' @keywords SharpeRatio
#' @export

printSharpeRatio <- function(data, y, fcst, pos, tcost = 0.02, printDetails = T, saveDetails = T)
    # y= yvar vector
    # fcst =xvar vector
{
    regdata <- data.table::data.table(data) %>%
        dplyr::select(SYM, DATE)

    regdata$fcst <- fcst
    regdata$y <- y
    regdata$pos <- pos
    regdata$tcost <- tcost

    lmfit <- lm(formula = y ~ fcst,data = regdata)

    regdata <- regdata %>%
        dplyr::group_by(SYM) %>%
        dplyr::mutate( pnl = y*pos - tcost * abs(pos - dplyr::lag(pos, default = 0, order_by = DATE)) ) %>%
        dplyr::mutate( absPosChg = abs(pos - dplyr::lag(pos, default = 0, order_by = DATE)) )

    # ----------------------
    # Calculate the summarized statistics
    pnlStd <- sd(regdata$pnl)
    contractSharpeRatio <- mean(regdata$pnl) / pnlStd
    contractSharpeRatioPA <- contractSharpeRatio*sqrt(252)

    groupData <- regdata %>%
        dplyr::group_by(DATE) %>%
        dplyr::summarise(pnl = sum(pnl))

    portpnlStd <- sd(groupData$pnl)
    portfolioSharpeRatio <- mean(groupData$pnl) / portpnlStd
    portfolioSharpeRatioPA <- portfolioSharpeRatio*sqrt(252)

    # Max Drawdown
    MDD <- tseries::maxdrawdown(cumsum(groupData$pnl))$maxdrawdown / portpnlStd / sqrt(252)


    skew=moments::skewness(regdata$pnl)
    kurt=moments::kurtosis(regdata$pnl)


    contractPnl <- round(c(summary(regdata$pnl),pnlStd,skew,kurt,contractSharpeRatio,contractSharpeRatioPA),digits=7)
    names(contractPnl) <- c("min","Q1","median","mean","Q3","max","std","skew","kurt","pcShp","pcShp.pa");


    skewPort=moments::skewness(groupData$pnl)
    kurtPort=moments::kurtosis(groupData$pnl)


    portfolioPnl <- round(c(summary(groupData$pnl),portpnlStd,  skewPort,kurtPort,portfolioSharpeRatio, portfolioSharpeRatioPA, MDD),digits=7)
    names(portfolioPnl) <- c("min","Q1","median","mean","Q3","max","std","skew","kurt","portShp","portShp.pa", "MDD");

    divNum <- c(portfolioSharpeRatioPA, contractSharpeRatioPA, portfolioSharpeRatio / contractSharpeRatio)
    names(divNum) <- c("portShp.pa","pcShp.pa","divNum")


    # turnover meansurement
    concatTable <- regdata %>%
        group_by(SYM) %>%
        dplyr::summarise(totalAbsPosChg = sum(absPosChg), totalAbsPos = sum(abs(pos)))
    turnover <- round(sum(concatTable$totalAbsPosChg) / sum(concatTable$totalAbsPos, na.rm = T), digits = 7)

    # return results
    Results <- list(contractPnl = contractPnl ,
                    portfolioPnl = portfolioPnl,
                    divNum = divNum,
                    turnover = turnover)
    if (printDetails) {
        print(Results)
    }

    if (saveDetails) {
        # addtional Results, to save space
        addResults <- list(lmfit = lmfit,
                           linearRegression = summary(lmfit),
                           y = regdata$y,
                           fcst = regdata$fcst,
                           pos = regdata$pos,
                           absPosChg = regdata$absPosChg,
                           contractDailyPnl = regdata$pnl,
                           portfolioDailyPnl = groupData$pnl)

        Results <- c(Results, addResults)
    }

    return( Results )
}
