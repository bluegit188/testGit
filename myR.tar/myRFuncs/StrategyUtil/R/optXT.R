#' optXT Function
#'
#' This function allows to get size based on optXT method
#' @param fcst
#' @param sizeX
#' @keywords optXT
#' @export

optXT <- function(fcst, sizeX = 0.0) {
    pos <- (abs(fcst) - sizeX) * (abs(fcst) > sizeX) * sign(fcst)
    return(pos)
}
