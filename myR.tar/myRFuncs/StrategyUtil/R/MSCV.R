#' MSCV Function
#'
#' This function allows to get the maximize sharpe ratio based on cross validation of DATE.
#' @param model model
#' @param data data
#' @param Nfold split data into Nfold based on DATE
#' @export

MSCV <- function(model, data, Nfold = 10) {
    # Check inputs
    if (missing(data))
        stop("Need to specify the data table.")
    if (!any("DATE" == colnames(data))) {
        stop("data need DATE column!!")
    }

    # cut Date into Nfold
    data <- data.table::data.table(data)
    data <- data %>%
        dplyr::mutate(CVgroup = cut(DATE, c(-Inf, quantile(DATE, c(1:Nfold)/Nfold, na.rm =T) ), label = FALSE))

    fcst <- numeric(dim(data)[1]) # initial fcst = 0
    for (groupID in c(1:Nfold)) {
        # define test and train set
        trainSet <- data %>% dplyr::filter(CVgroup != groupID)
        testSet <- data %>% dplyr::filter(CVgroup == groupID)

        trainRes <- MS(model, trainSet)

        mf <- model.frame(formula = model, data = testSet)
        testX <- model.matrix(attr(mf, "terms"), data = mf)
        fcst[data$CVgroup == groupID] <- testX %*% matrix(as.numeric(trainRes$coefList$coef), , 1)
    }

    res <- list()
    res$coefList <- data.table(indicator = ' ', coef = 0)
    res$fcst <- fcst
    return(res)
}
