#' optZ Function
#'
#' This function allows to get size based on optZ method
#' @param fcst
#' @param SYM
#' @param sizeX
#' @keywords optZ
#' @export

optZ <- function(fcst, SYM, sizeX = 0.0) {
    len <- length(fcst)
    pos <- numeric(len)
    pos[1] <- (abs(fcst[1]) - sizeX) * sign(fcst[1])
    for (i in c(2:len)) {
        if (SYM[i-1] != SYM[i]) {
            pos[i] <- 0
        } else {
            if (pos[i-1] > fcst[i]) {
                pos[i] <- min(fcst[i] + sizeX, pos[i-1])
            } else {
                pos[i] <- max(fcst[i] - sizeX, pos[i-1])
            }
        }
    }

    return(pos)
}
