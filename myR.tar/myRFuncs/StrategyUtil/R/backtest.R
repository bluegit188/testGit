#' backtest Function
#'
#' This function allows to backtest strategies based on pipeline framework
#' @param model
#' @param data
#' @param fcstMethod OLS, MS, OLSCV, MSCV
#' @param posMethod	optX, optXT, optZ, optZA
#' @param sizeX	size method parameter
#' @param tcost	transaction cost
#' @param Nfold when using cross validation, split data into Nfold
#' @export

backtest <- function(model,
                     data,
                     fcstMethod = 'OLS',
                     posMethod = 'optX',
                     sizeX = 0.0,
                     sizeY = 0.0,
                     tcost = 0.02,
                     Nfold = 10,
                     refit = T,
                     printDetails = T,
                     saveDetails = T)
{
    # Check inputs
    if (missing(data))
        stop("Need to specify the data table.")
    if (!any("DATE" == colnames(data))) {
        stop("data need DATE column!!")
    }
    if (!any("SYM" == colnames(data))) {
        stop("data need SYM column!!")
    }

    data <- data.table::data.table(data)

    # get fcst
    if (!refit) {
        # use external source to fit
        if (!any("data.frame" == class(model)) | !any("data.table" == class(model))) {
            stop("User-defined (refit == F) model class must be 'data.frame' or 'data.table'.\n")
        }
        if (dim(model)[1] != dim(data)[1]) {
            stop("User-defined (refit == F) model must have the same length as data.\n")
        }
        if (!any("fcst" == colnames(model)) | !any("y" == colnames(model))) {
            stop("User-defined (refit == F) model must have columns 'fcst' and 'y'.\n")
        }
        fcst <- model$fcst
        y <- model$y
        coefList <- NULL
    } else {
        mf <- model.frame(formula=model, data=data)
        y <- model.response(mf)
        if (printDetails) {
            cat("MODEL:\n")
            cat(deparse(model),'\n\n')
        }
        if (fcstMethod == 'OLS') {
            fcstList <- OLS(model, data)
        } else if (fcstMethod == 'MS') {
            fcstList <- MS(model, data)
        } else if (fcstMethod == 'OLSCV') {
            fcstList <- OLSCV(model, data, Nfold = Nfold)
        } else if (fcstMethod == 'MSCV') {
            fcstList <- MSCV(model, data, Nfold = Nfold)
        } else {
            stop("fcstMethod can only be OLS, MS, OLSCV or MSCV.")
        }
        fcst <- fcstList$fcst
        coefList <- fcstList$coefList
    }

    # get position based on fcst
    if (posMethod == 'optZA') {
        # need SYM column to reset the pos to 0 when cross symbol
        pos = optZA(fcst, data$SYM, sizeX,sizeY)
    } else if (posMethod == 'optZ') {
        # need SYM column to reset the pos to 0 when cross symbol
        pos = optZ(fcst, data$SYM, sizeX)
    } else if (posMethod == 'optXT') {
        pos = optXT(fcst, sizeX)
    } else if (posMethod == 'optX') {
        pos = optX(fcst, sizeX)
    } else {
        stop("posMethod can only be optX, optXT, optZ, optZA.")
    }

    # print details of summarized table
    res <- printSharpeRatio(data, y, fcst, pos, tcost, printDetails, saveDetails)
    res$coefList <- coefList

    return(res)
}
