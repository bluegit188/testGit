#' optZA Function
#'
#' This function allows to get size based on optZA method
#' @param fcst
#' @param SYM
#' @param sizeX
#' @keywords optZA
#' @export

optZA <- function(fcst, SYM, sizeX = 0.0,sizeY=0.0) {
    len <- length(fcst)
    pos <- numeric(len)
    pos[1] <- (abs(fcst[1]) - sizeX) * sign(fcst[1])* (abs(fcst[1])-sizeX > 0)
    for (i in c(2:len)) {
        if (SYM[i-1] != SYM[i]) {
            pos[i] <- (abs(fcst[i]) - sizeX) * sign(fcst[i])*(abs(fcst[i])-sizeX > 0)
        } else {
            if (pos[i-1] > fcst[i]) {
                pos[i] <- min(fcst[i] + sizeX, pos[i-1])
            } else {
                pos[i] <- max(fcst[i] - sizeX, pos[i-1])
            }
            #pos[i] <- pos[i] * (pos[i]*fcst[i] > 0)
            pos[i] <- pos[i] * ifelse(pos[i]*fcst[i] > 0 | (pos[i]*fcst[i] < 0 & abs(fcst[i])<= sizeY),1,0)           
        }
    }

    return(pos)
}
