#' optX Function
#'
#' This function allows to get size based on optX method
#' @param fcst
#' @param sizeX
#' @keywords optX
#' @export

optX <- function(fcst, sizeX = 0.0) {
    pos <- fcst * (abs(fcst) > sizeX)
    return(pos)
}
