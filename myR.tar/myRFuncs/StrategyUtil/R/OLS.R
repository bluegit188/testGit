#' OLS Function
#'
#' This function allows to get the minimized least square parameters.
#' @param model,
#' @param data
#' @keywords OLS
#' @export
#' @examples
#' OLS(ooF1D~bt1FcstDM,dat0)
#'
#' # create X quartiles
#' dat0$X <- (dat0$fvChg.1)
#' dat0$XQtr <- cut(dat0$X, c(-Inf, quantile(dat0$X, c(25,50,75,100)/100, na.rm =T) ))
#' OLS(ooF1D~bt1FcstDM:I(XQtr), data = dat0)
#'

OLS <- function(model, data) {
    # lm method
    lmfit <- lm(model, data)
    y <- lmfit$fitted.values + lmfit$resid

    coef <- data.table( names(lmfit$coefficients), round(lmfit$coefficients,digits=7))
    names(coef) = c("indicator", "coef")
    res <- list()
    res$coefList <- coef
    res$fcst <- lmfit$fitted.values

    return(res)
}
