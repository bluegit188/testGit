interpolateOO22t252<- function(xV,xVec,fcstVec)
# the grid is fine so not really interpolate, just take the cloest values
# xV is a vector of input values of OO.22t252
{
   ifelse(xV< -60,-60,xV)
   ifelse(xV> 76,76,xV)

   yhatVec=xV;

   for (i in 1:length(xV) )
   {
     x=xV[i]
     dif=abs(x-xVec)
     idx=which.min(dif) # min dif loc
     yhatVec[i]=fcstVec[idx]
   }
   
   yhatVec
}

#examples

#grid<-fread("~/transfer/Prod/LTGridNew_20170803.txt")
#names(grid)=c("OO22t252","OO22t252N","fcstSS")
#summary(grid)

#fcstSSJF=interpolateOO22t252(regdata$OO.22t252,grid$OO22t252,grid$fcstSS)

