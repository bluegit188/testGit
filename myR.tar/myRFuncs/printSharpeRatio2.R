printSharpeRatio2 <- function(dataTable, depVar, indepVar) 
# depVar= yvar vector
# indepVar =xvar vector
{
  lmfit <- lm(formula = depVar ~ indepVar,data=dataTable)

  dataTable$pnl <- depVar * indepVar

  pnlStd= sd(dataTable$pnl)
  contractSharpeRatio <- mean(dataTable$pnl) / pnlStd
  contractSharpeRatio
  contractSharpeRatioPA=  contractSharpeRatio*sqrt(252)

  groupData <- dataTable %>%
    group_by(DATE) %>%
    summarise(pnl = sum(pnl))

  ppnlStd=sd(groupData$pnl)
  portfolioSharpeRatio <- mean(groupData$pnl) / ppnlStd
  portfolioSharpeRatio
  portfolioSharpeRatioPA= portfolioSharpeRatio*sqrt(252)

  divNum0 <- portfolioSharpeRatio / contractSharpeRatio

  contractPnl = round(c(summary(dataTable$pnl),pnlStd,contractSharpeRatio,contractSharpeRatioPA),digits=7)
  names(contractPnl)=c("min","Q1","median","mean","Q3","max","std","pcShp","pcShp.pa");

  portfolioPnl = round(c(summary(groupData$pnl),ppnlStd, portfolioSharpeRatio, portfolioSharpeRatioPA),digits=7)
  names(portfolioPnl)=c("min","Q1","median","mean","Q3","max","std","portShp","portShp.pa");

  divNum = c(portfolioSharpeRatioPA,contractSharpeRatioPA,divNum0)
  names(divNum)=c("portShp.pa","pcShp.pa","divNum")

  print("here")
    # turnover meansurement
    turnoverData <- dataTable %>%
        group_by(SYM) %>%
        summarise( turnover=sum(abs(x - dplyr::lag(x, default = 0)) / sum(abs(x)), na.rm = T))
  print("here2")

  results <- list(depVar = deparse(substitute(depVar)),
                  indepVar = deparse(substitute(indepVar)),
                  linearRegression = summary(lmfit),
                  contractPnl =	contractPnl ,
                  portfolioPnl = portfolioPnl,
                  divNum = divNum,
                  turnover = data.table(turnoverData) )
  print( results )

}

