library(kknn)
library(data.table)


## Inputs: 
## x, y, DATE are data columns/lists of equal length; if no actual DATE column, can be replaced by c(1:length(x))
## nfold is the number of folds for the cross validation of the data; for Leave-1-Out CV, set nfold = "L1O"
## k is the number of nearest neighbors
## Returns plot of yhat_knn vs x from a knn where the data undergoes n-fold CV based on the DATE
## usage: 
##  plot_knnfcst(x=regdata$OO1, y=regdata$ooF1D, DATE=regdata$DATE, nfold=10, k=2000) 
## plot_knnfcst(x=regdata$OO1, y=regdata$ooF1D, DATE=regdata$DATE, nfold="L1O", k=2000) # for leave one out 

plot_knnfcst = function(x, y, DATE, nfold, k){
  data = data.frame(x, y, DATE)
  names(data) = c("x", "y", "DATE")
  datelist = unique(DATE)
  datelist = sort(datelist)
  
  if(nfold=="L1O"){
    fold_size=1
    nfold2 = length(datelist)-1
  }else{
    fold_size = max(1, floor(length(datelist)/nfold))
    nfold2 = nfold
  }
  
  cv_set = data.frame()
  for(n in c(0:(nfold2-1))){
    #start_index = n+1
    start_index = n*fold_size +1

    end_index = start_index + fold_size
    
    cv_trainset = data[data$DATE < datelist[start_index] | data$DATE >= datelist[end_index],]
    cv_validset = data[data$DATE >= datelist[start_index] & data$DATE<datelist[end_index],]
    
    #print(paste(n, length(cv_trainset$x), length(cv_validset$x), fold_size, start_index, end_index, datelist[start_index], datelist[end_index]))
    
    lmcv = lm(y~x, data=cv_trainset)
    cv_validset$yhat_lm = predict(lmcv, newdata=cv_validset)
    knncv = kknn(y~x, train=cv_trainset, test=cv_validset, k=k, kernel="rectangular")
    cv_validset$yhat_knn = knncv$fitted.values
    
    append_df = data.frame(cv_validset$y, cv_validset$yhat_lm, cv_validset$yhat_knn, cv_validset$x)
    names(append_df) = c("y", "yhat_lm", "yhat_knn", "x")
    cv_set = rbind(cv_set, append_df)
  }
  
  plot(cv_set$x, cv_set$yhat_knn)
}

