#!/usr/bin/perl

use strict;

($#ARGV+2)==7 || die 
"Usage: get_portfolioShp_with_tcosts_naive.pl file.txt colSym colDate colY colFcst tcost(0.02)
       Compute porfolio shp and per commodity shp assuming linear tcost: no opt entry rules\n";


# open file an dput column specified into a hash
my $filename=$ARGV[0];

my $colSym=$ARGV[1];
my $colDate=$ARGV[2];
my $colY=$ARGV[3];
my $colFcst=$ARGV[4];
my $tcost=$ARGV[5];


 my $cmd0="
head -1 $filename |mygetcols.pl $colFcst
";
 my $res0=`$cmd0`;
 chomp($res0);
my $indName=$res0;



 my $cmd0a="
head -1 $filename |wc|mygetcols.pl 2
";
 my $res0a=`$cmd0a`;
 chomp($res0a);
my $numCols=$res0a;

my $colPL= $numCols+3;

print "Portfolio shp: file= $filename, fcst= $indName tcost=$tcost:\n";
    my $cmd1="
## compute shp
#cat $filename |fgrep -v DATE|mygetcols.pl $colDate $colSym $colY $colFcst| gawk '{print \$0,\$3*\$4- $tcost*sqrt(\$4*\$4)}' |mygetcols.pl 1 2 5 |myAddHeader.sh \"DATE SYM PL\" >pls.txt.$indName
cat $filename |myAfterTcostPnl_naive.pl 1 $colSym $colDate $colY $colFcst $tcost|mygetcols.pl $colDate $colSym $colPL |fgrep -v DATE | myAddHeader.sh \"DATE SYM PL\" >pls.txt.$indName
#pcShp
getstat_fast.pl pls.txt.$indName 1 3|fgrep -v std|gawk '{print \$0,\$4/\$5,\$4/\$5*sqrt(252) }'|myAddHeader.sh \"colName   min   max   mean    std    count   shp   shp.pa\"|gawk '{print \"pcShp= \",\$0}' >tmp_pcShp.txt
";
# print "$cmd1\n";
   system("$cmd1");


    my $cmd2="
 #portShp
getMeanStdByDate.pl pls.txt.$indName 1 1 3|gawk '{print \$1,\$4*\$6,\$6}' |myAddHeader.sh \"DATE PPL count\" >ppls.txt.$indName
getstat_fast.pl ppls.txt.$indName 1 2|fgrep -v std|gawk '{print \$0,\$4/\$5,\$4/\$5*sqrt(252)}'|myAddHeader.sh \"colName min max mean std count shp shp.pa\" |gawk '{print \"portShp= \",\$0}' >tmp_portShp.txt
cat tmp_pcShp.txt tmp_portShp.txt |myFormatAuto.pl 1
";
  # print "$cmd2\n";
   system("$cmd2");

 my $cmd3="
cat tmp_pcShp.txt|fgrep -v colName|mygetcols.pl 8
#0.0420067
";
 my $res3=`$cmd3`;
 chomp($res3);
my $pcShp=$res3;


 my $cmd4="
cat tmp_portShp.txt|fgrep -v colName|mygetcols.pl 8
#0.0420067
";
 my $res4=`$cmd4`;
 chomp($res4);
my $portShp=$res4;
my $divNum=$portShp/$pcShp;
printf "divNum = portShp/pcShp= $portShp / $pcShp = %.7f\n",$divNum;


__END__


 my $cmd="wc test.txt| head -1 |mygetcols.pl 1";
 my $res=`$cmd`;
 chomp($res);

