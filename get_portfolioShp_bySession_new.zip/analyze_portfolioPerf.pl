#!/usr/bin/perl

use strict;

( ($#ARGV+2)==6|| ($#ARGV+2)==9 ) || die 
"Usage: analyze_portfolioPerf.pl file.txt colSym colDate colY colFcst [optional: sizeX sizeY tcost]
       Compute a few portfolio stats:
       sizeY is used for optZAY only.
        pcShp and portShp
        shp by year
        shp by symbol\n";


# open file an dput column specified into a hash
my $filename=$ARGV[0];

my $colSym=$ARGV[1];
my $colDate=$ARGV[2];
my $colY=$ARGV[3];
my $colFcst=$ARGV[4];

my $entry=0.03;
my $tcost=0.03;
my $exit=0.005;

if(($#ARGV+2)==9)
{
   $entry=$ARGV[5];
   $exit=$ARGV[6];
   $tcost=$ARGV[7];

}

 my $cmd0="
head -1 $filename |mygetcols.pl $colFcst
";
 my $res0=`$cmd0`;
 chomp($res0);
my $indName=$res0;

 my $cmd01="
head -1 $filename |mygetcols.pl $colY
";
 my $res01=`$cmd01`;
 chomp($res01);
my $yName=$res01;

# num of syms
 my $cmd001="
check_duplicate.pl $filename $colSym|fgrep -v SYM|mygetcols.pl 1|wc|mygetcols.pl 1
#26
";
 my $res001=`$cmd001`;
 chomp($res001);
my $numSyms=$res001;



# date range
 my $cmd002="
check_duplicate.pl  $filename $colDate|fgrep -v DATE|mygetcols.pl 1|myRange.pl 0 1|mygetcols.pl 3 5
#20070102 20160531

";
 my $res002=`$cmd002`;
 chomp($res002);
my $dateRange=$res002;



print "######## turnover, fcst= $indName ###############\n";
   my $cmd1a="
compute_fcst_turnover.pl  $filename  $colFcst
";
# print "$cmd1a\n";
   system("$cmd1a");


############### naive netShp method ##########

print "\n\n######## net shp, naive tcost method, tcost=$tcost fcst= $indName ###############\n";
   my $cmd1a="
get_portfolioShp_with_tcosts_naive.pl  $filename  $colSym $colDate $colY $colFcst $tcost
";
# print "$cmd1a\n";
   system("$cmd1a");


############### optXT method ##########

print "\n\n######## netShp, opt entry/XT method, entry=$entry tcost=$tcost fcst= $indName ###############\n";
   my $cmd1b="
get_portfolioShp_with_tcosts_optEntry.pl  $filename  $colSym $colDate $colY $colFcst $entry $tcost
";
 print "cmd= $cmd1b\n";
   system("$cmd1b");

  my $cmd1c="
cp  pls.txt.$indName  pls.txt.tcost.$indName
cp ppls.txt.$indName  ppls.txt.tcost.$indName
#cp tmp_ppls_yearmon.txt tmp_ppls_yearmon.tcost.txt

 #port shp by year
 getMeanStdByDate.pl pls.txt.tcost.$indName 1 1 3|gawk '{print \$1,\$4*\$6,\$6}' |myYearMon.pl 0  1 >tmp_ppls_yearmon.tcost.txt

";
 #print "cmd= $cmd1c\n";
   system("$cmd1c");


############### optZA method ##########


print "\n\n######## netShp, optZA method, entry=$entry tcost=$tcost fcst= $indName ###############\n";
   my $cmd1bza="
get_portfolioShp_with_tcosts_optEntry_ZA.pl  $filename  $colSym $colDate $colY $colFcst $entry $tcost
";
 print "cmd= $cmd1bza\n";
   system("$cmd1bza");



############### optZAY method ##########


print "\n\n######## netShp, optZAY method, entry=$entry  exit=$exit tcost=$tcost fcst= $indName ###############\n";
   my $cmd1bza="
get_portfolioShp_with_tcosts_optEntry_ZAY.pl  $filename  $colSym $colDate $colY $colFcst $entry $exit $tcost
";
 print "cmd= $cmd1bza\n";
   system("$cmd1bza");






############### gross shp ##########



print "\n\n######## gross pcShp and portShp,  yvar=$yName fcst= $indName ###############\n";
print "Number of symbols: $numSyms , Date range: $dateRange\n";

    my $cmd1="
get_portfolioShp.pl  $filename  $colSym $colDate $colY $colFcst
";
# print "$cmd1\n";
   system("$cmd1");


print "\n\n######## shp by year, fcst= $indName ###############\n";
    my $cmd2="
get_portfolioShp_byYear.pl pls.txt.$indName
";
# print "$cmd2\n";
   system("$cmd2");

print "\n\n######## shp by yearmon, fcst= $indName ###############\n";
    my $cmd2="
get_portfolioShp_byYearMon.pl pls.txt.$indName
";
# print "$cmd2\n";
   system("$cmd2");



print "\n\n######## shp by symbol, fcst= $indName ###############\n";
    my $cmd3="
get_portfolioShp_bySym.pl pls.txt.$indName
";
  # print "$cmd3\n";
   system("$cmd3");


print "\n\n######## shp by asset, fcst= $indName ###############\n";
    my $cmd3="
get_portfolioShp_byAsset_new.pl pls.txt.$indName
";
  # print "$cmd3\n";
   system("$cmd3");


print "\n\n######## shp by session, fcst= $indName ###############\n";
    my $cmd3="
get_portfolioShp_bySession_new.pl pls.txt.$indName
";
  # print "$cmd3\n";
   system("$cmd3");


print "\n\n######## shp by DOW (gross), fcst= $indName ###############\n";
    my $cmd3="
get_portfolioShp_byDOW_pct.pl pls.txt.$indName
";
  # print "$cmd3\n";
   system("$cmd3");



print "\n\n######## max drawdown, daily ret, fcst= $indName ###############\n";
    my $cmd3="
get_max_drawdown.pl ppls.txt.$indName  1 1 2
";
  # print "$cmd3\n";
   system("$cmd3");


print "\n\n######## max drawdown, monthly ret, fcst= $indName ###############\n";
    my $cmd3="
getMeanStdByDate.pl tmp_ppls_yearmon.txt 0 4 2|gawk '{print \$1, \$4*\$6,\$6}' >tmp_ppl_monthlyRet_yeanmon.txt
get_max_drawdown.pl tmp_ppl_monthlyRet_yeanmon.txt 0 1 2
";
  # print "$cmd3\n";
   system("$cmd3");





print "\n\n######## max drawdown of after tcost ret, daily ret, fcst= $indName ###############\n";
    my $cmd3="
#get_max_drawdown.pl ppls.txt.tcost.$indName  1 1 2
get_max_drawdown.pl ppls.txt.$indName.netZA 1 1 2
";
  # print "$cmd3\n";
   system("$cmd3");


print "\n\n######## max drawdown of after tcost ret, monthly ret, fcst= $indName ###############\n";
    my $cmd3="
#getMeanStdByDate.pl tmp_ppls_yearmon.tcost.txt 0 4 2|gawk '{print \$1, \$4*\$6,\$6}' >tmp_ppl_monthlyRet_yeanmon.tcost.txt
#get_max_drawdown.pl tmp_ppl_monthlyRet_yeanmon.tcost.txt 0 1 2
cat ppls.txt.$indName.netZA|myYearMon.pl 1 1|fgrep -v DATE >ppls.txt.$indName.netZA.yearmon
getMeanStdByDate.pl ppls.txt.$indName.netZA.yearmon 0 4 2|gawk '{print \$1, \$4*\$6,\$6}' >tmp_ppl_monthlyRet_yeanmon.tcost.txt.netZA
get_max_drawdown.pl tmp_ppl_monthlyRet_yeanmon.tcost.txt.netZA 0 1 2

";
  # print "$cmd3\n";
   system("$cmd3");


print "\n\n######## net ppls corr to ES daily, fcst= $indName ###############\n";
    my $cmd30="
portara_get_ooRets.pl ES 1|mygetcols.pl 2 3 >tmp_esF1D.txt
# combine_match1.pl tmp_esF1D.txt ppls.txt.$indName |mygetcols.pl 1 2 4|fgrep -v DATE|myAddHeader.sh \"DATE ES $indName\" >tmp_compare_ppl_withES.txt
 combine_match1.pl tmp_esF1D.txt ppls.txt.tcost.$indName |mygetcols.pl 1 2 4|fgrep -v DATE|myAddHeader.sh \"DATE ES $indName\" >tmp_compare_ppl_withES.txt
get_corr_matrix_R.pl tmp_compare_ppl_withES.txt 0 >a
cat tmp_correlation.txt |egrep -E -e\"^ES \"|mygetcols.pl 4
";
 my $res30=`$cmd30`;
 chomp($res30);
my $corr=$res30;


   print "$indName corr To ES(daily): $corr\n";


print "\n\n######## net ppls corr to CTA daily, fcst= $indName ###############\n";
    my $cmd31="
#portara_get_ooRets.pl ES 1|mygetcols.pl 2 3 >tmp_esF1D.txt
# combine_match1.pl tmp_esF1D.txt ppls.txt.$indName |mygetcols.pl 1 2 4|fgrep -v DATE|myAddHeader.sh \"DATE ES $indName\" >tmp_compare_ppl_withES.txt
cp /home/jgeng/bin/BenchRets/ctaDaily.txt tmp_ctaDaily.txt
 combine_match1.pl tmp_ctaDaily.txt ppls.txt.tcost.$indName |mygetcols.pl 1 2 4|fgrep -v DATE|myAddHeader.sh \"DATE CTA $indName\" >tmp_compare_ppl_withCTA.txt
get_corr_matrix_R.pl tmp_compare_ppl_withCTA.txt 0 >a
cat tmp_correlation.txt |egrep -E -e\"^CTA \"|mygetcols.pl 4
";
 my $res31=`$cmd31`;
 chomp($res31);
my $corrCTA=$res31;


   print "$indName corr To CTA(daily): $corrCTA\n";



print "\n\n######## net ppls corr to SP/CTA monthly, fcst= $indName ###############\n";
   my $cmd32="
cp /home/jgeng/bin/BenchRets/sp_cta_monthlyRet.txt tmp_spCtaMonthly.txt
cat tmp_ppl_monthlyRet_yeanmon.tcost.txt |mygetcols.pl 1 2|myAddHeader.sh \"DATE $indName\" >ppls_monthly.tcost.txt.$indName
combine_match1.pl  tmp_spCtaMonthly.txt  ppls_monthly.tcost.txt.$indName |mygetcols.pl 1 2 3 4 6 >tmp_compare_ppl_monthly_withSPCTA.txt
get_corr_matrix_R.pl tmp_compare_ppl_monthly_withSPCTA.txt 0 >a
#cat tmp_correlation.txt |egrep -E -e\"^CTA \"|mygetcols.pl 4
cat tmp_correlation.txt|myFormatAuto.pl 1
";
system("$cmd32");


print "\n\n######## net ppls corr to some static bench rets monthly, fcst= $indName ###############\n";

   my $cmd33="
cp /home/jgeng/bin/BenchRets/final_LT_bench_compare.txt.full.selectFunds.withCombo tmp_final_LT_bench_compare.txt.full.selectFunds.withCombo
cat tmp_ppl_monthlyRet_yeanmon.tcost.txt |mygetcols.pl 1 2|myAddHeader.sh \"DATE $indName\" >ppls_monthly.tcost.txt.$indName
combine_match1.pl  ppls_monthly.tcost.txt.$indName tmp_final_LT_bench_compare.txt.full.selectFunds.withCombo   |myrmcols.pl  3 4 7 9 10   >tmp_compare_ppl_monthly_withBenchs.txt
get_corr_matrix_R.pl tmp_compare_ppl_monthly_withBenchs.txt 0 >a
cat tmp_correlation.txt|myrmcols.pl 2 |myFormatAuto.pl 1
";
system("$cmd33");


print "\n\n######## last 5Y(since 2011/09) corr to static bench rets monthly, fcst= $indName ###############\n";

   my $cmd34="
more tmp_compare_ppl_monthly_withBenchs.txt|myRmOutliersSimple.pl  1 1 201109 202001 1 >tmp_compare_ppl_monthly_withBenchs.txt.last5Y
get_corr_matrix_R.pl tmp_compare_ppl_monthly_withBenchs.txt.last5Y 0 >a
cat tmp_correlation.txt|myrmcols.pl 2 |myFormatAuto.pl 1
";
system("$cmd34");


